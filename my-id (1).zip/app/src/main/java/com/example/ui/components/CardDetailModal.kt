package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.IdCardEntity
import com.example.ui.DisclosureAttribute

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardDetailModal(
    card: IdCardEntity,
    isMasked: Boolean,
    disclosedAttributes: Set<DisclosureAttribute>,
    onToggleDisclosure: (DisclosureAttribute) -> Unit,
    onPresentCard: (IdCardEntity) -> Unit,
    onPinToggle: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    var isFlipped by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.testTag("card_detail_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = card.title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Interactive Flippable Card View
            IdCardView(
                card = card,
                isMasked = isMasked,
                isFlipped = isFlipped,
                onFlip = { isFlipped = !isFlipped },
                onPinToggle = onPinToggle
            )

            Text(
                text = if (isFlipped) "Showing back (MRZ & Emergency info) • Tap flip to return" else "Tap ↻ or button below to inspect card back",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        onDismiss()
                        onPresentCard(card)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("present_card_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.QrCode, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Present & Share", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { isFlipped = !isFlipped },
                    modifier = Modifier.height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Sync, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isFlipped) "Front" else "Flip")
                }

                IconButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier.size(48.dp).testTag("delete_card_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete Card",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Selective Disclosure Privacy Control
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Selective Disclosure Protection",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(
                        text = "Zero-Knowledge Proof: Choose attributes revealed during QR / NFC scans",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    DisclosureRow(
                        label = "Full Legal Name",
                        isChecked = disclosedAttributes.contains(DisclosureAttribute.FULL_NAME),
                        onToggle = { onToggleDisclosure(DisclosureAttribute.FULL_NAME) }
                    )
                    DisclosureRow(
                        label = "Legal Age Proof (Over 21) without full DOB",
                        isChecked = disclosedAttributes.contains(DisclosureAttribute.AGE_OVER_21_ONLY),
                        onToggle = { onToggleDisclosure(DisclosureAttribute.AGE_OVER_21_ONLY) }
                    )
                    DisclosureRow(
                        label = "Exact Date of Birth (${card.dateOfBirth})",
                        isChecked = disclosedAttributes.contains(DisclosureAttribute.EXACT_DOB),
                        onToggle = { onToggleDisclosure(DisclosureAttribute.EXACT_DOB) }
                    )
                    DisclosureRow(
                        label = "Document ID Number (${card.documentNumber})",
                        isChecked = disclosedAttributes.contains(DisclosureAttribute.DOCUMENT_NUMBER),
                        onToggle = { onToggleDisclosure(DisclosureAttribute.DOCUMENT_NUMBER) }
                    )
                    DisclosureRow(
                        label = "Residential Address",
                        isChecked = disclosedAttributes.contains(DisclosureAttribute.ADDRESS),
                        onToggle = { onToggleDisclosure(DisclosureAttribute.ADDRESS) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Metadata List
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "CREDENTIAL SPECIFICATIONS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )

                    DetailRow("Issuing Authority", card.issuingAuthority)
                    DetailRow("Document Number", card.documentNumber)
                    DetailRow("Issue Date", card.issueDate)
                    DetailRow("Expiry Date", card.expiryDate)
                    DetailRow("Security Level", card.securityLevel)
                    DetailRow("Status", card.status)
                    if (card.departmentOrClass.isNotBlank()) {
                        DetailRow("Classification", card.departmentOrClass)
                    }
                    if (card.emergencyContact.isNotBlank()) {
                        DetailRow("Emergency Contact", card.emergencyContact)
                    }
                }
            }

            if (showDeleteConfirm) {
                AlertDialog(
                    onDismissRequest = { showDeleteConfirm = false },
                    title = { Text("Remove from My ID Vault?") },
                    text = { Text("Are you sure you want to remove '${card.title}'? This will delete the encrypted credential from this device.") },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                showDeleteConfirm = false
                                onDelete()
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Delete")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDeleteConfirm = false }) {
                            Text("Cancel")
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun DisclosureRow(
    label: String,
    isChecked: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.5.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
        Switch(
            checked = isChecked,
            onCheckedChange = { onToggle() },
            modifier = Modifier.height(28.dp)
        )
    }
}

@Composable
private fun DetailRow(title: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
