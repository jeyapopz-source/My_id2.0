package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.abs

@Composable
fun QrCodeView(
    payload: String,
    modifier: Modifier = Modifier,
    backgroundColor: Color = Color.White,
    codeColor: Color = Color(0xFF060D1E)
) {
    // Generate deterministic 21x21 QR code matrix based on payload
    val matrix = remember(payload) {
        generateQrMatrix(payload, 25)
    }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(12.dp))
            .background(backgroundColor)
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val sizeCount = matrix.size
            val cellSize = size.width / sizeCount

            for (row in 0 until sizeCount) {
                for (col in 0 until sizeCount) {
                    if (matrix[row][col]) {
                        drawRect(
                            color = codeColor,
                            topLeft = Offset(col * cellSize, row * cellSize),
                            size = Size(cellSize, cellSize)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BarcodeView(
    payload: String,
    modifier: Modifier = Modifier,
    barColor: Color = Color(0xFF0F172A),
    backgroundColor: Color = Color.White
) {
    val barPattern = remember(payload) {
        generateBarcodePattern(payload)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(backgroundColor)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val totalBars = barPattern.size
            val barWidth = size.width / totalBars.toFloat()

            barPattern.forEachIndexed { index, isBlack ->
                if (isBlack) {
                    drawRect(
                        color = barColor,
                        topLeft = Offset(index * barWidth, 0f),
                        size = Size(barWidth, size.height)
                    )
                }
            }
        }
    }
}

private fun generateQrMatrix(payload: String, size: Int): Array<BooleanArray> {
    val matrix = Array(size) { BooleanArray(size) }

    fun drawFinder(startRow: Int, startCol: Int) {
        for (r in 0..6) {
            for (c in 0..6) {
                val isOuter = r == 0 || r == 6 || c == 0 || c == 6
                val isInner = r in 2..4 && c in 2..4
                matrix[startRow + r][startCol + c] = isOuter || isInner
            }
        }
    }

    // Three standard finder patterns
    drawFinder(0, 0)
    drawFinder(0, size - 7)
    drawFinder(size - 7, 0)

    // Timing lines
    for (i in 8 until size - 8) {
        matrix[6][i] = i % 2 == 0
        matrix[i][6] = i % 2 == 0
    }

    // Deterministic pseudo-random fill based on payload hash
    val hash = payload.hashCode()
    var seed = abs(hash).toLong()

    for (r in 0 until size) {
        for (c in 0 until size) {
            val inTopLeftFinder = r < 8 && c < 8
            val inTopRightFinder = r < 8 && c >= size - 8
            val inBottomLeftFinder = r >= size - 8 && c < 8
            val inTiming = r == 6 || c == 6

            if (!inTopLeftFinder && !inTopRightFinder && !inBottomLeftFinder && !inTiming) {
                seed = (seed * 1103515245 + 12345) and 0x7fffffff
                matrix[r][c] = (seed % 3L != 0L)
            }
        }
    }

    return matrix
}

private fun generateBarcodePattern(payload: String): List<Boolean> {
    val list = mutableListOf<Boolean>()
    // Start guard
    list.addAll(listOf(true, false, true))

    val hash = payload.hashCode()
    var seed = abs(hash).toLong()

    val length = 60
    for (i in 0 until length) {
        seed = (seed * 1664525 + 1013904223) and 0xffffffffL
        val width = ((seed % 3) + 1).toInt()
        val isBlack = (i % 2 == 0)
        repeat(width) {
            list.add(isBlack)
        }
    }

    // End guard
    list.addAll(listOf(true, false, true))
    return list
}
