package com.example.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.PortalIdsScreen
import com.example.ui.screens.SplashScreen

@Composable
fun MainApp(
    viewModel: IdViewModel = viewModel()
) {
    // 3-second Splash Screen state
    var showSplash by remember { mutableStateOf(true) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0A0E21)
    ) {
        Crossfade(
            targetState = showSplash,
            animationSpec = tween(500),
            label = "splash_to_home_transition"
        ) { isSplash ->
            if (isSplash) {
                SplashScreen(
                    onSplashComplete = {
                        showSplash = false
                    }
                )
            } else {
                // Home Screen: MY ID at top, 20 Service Cards, no bottom bar, no tagline
                PortalIdsScreen()
            }
        }
    }
}
