package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Core Colors based on My ID Logo
val BrandNavyDark = Color(0xFF060D1E)
val BrandNavySurface = Color(0xFF0E1A38)
val BrandNavyCard = Color(0xFF13234D)
val BrandNavyBorder = Color(0xFF243B73)

val BrandBlue = Color(0xFF0D47A1)
val BrandBlueLight = Color(0xFF1E88E5)
val BrandCyan = Color(0xFF00B0FF)
val BrandOrange = Color(0xFFFF6D00)
val BrandOrangeLight = Color(0xFFFF9100)
val BrandGreen = Color(0xFF00C853)
val BrandGreenLight = Color(0xFF10B981)

// Theme Swatches
val PrimaryLight = Color(0xFF0D47A1)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFD0E4FF)
val OnPrimaryContainerLight = Color(0xFF001D4B)

val SecondaryLight = Color(0xFFE65100)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFFDCC2)
val OnSecondaryContainerLight = Color(0xFF341100)

val TertiaryLight = Color(0xFF00796B)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFB2DFDB)
val OnTertiaryContainerLight = Color(0xFF00201B)

val BackgroundLight = Color(0xFFF6F8FD)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFE2EAF8)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

val PrimaryDark = Color(0xFF90CAF9)
val OnPrimaryDark = Color(0xFF002251)
val PrimaryContainerDark = Color(0xFF0A347B)
val OnPrimaryContainerDark = Color(0xFFD0E4FF)

val SecondaryDark = Color(0xFFFFB74D)
val OnSecondaryDark = Color(0xFF4E2600)
val SecondaryContainerDark = Color(0xFF7A3700)
val OnSecondaryContainerDark = Color(0xFFFFDCC2)

val TertiaryDark = Color(0xFF69F0AE)
val OnTertiaryDark = Color(0xFF003822)
val TertiaryContainerDark = Color(0xFF005234)
val OnTertiaryContainerDark = Color(0xFFB9F6CA)

val BackgroundDark = Color(0xFF070E22)
val SurfaceDark = Color(0xFF0E1A38)
val SurfaceVariantDark = Color(0xFF16254E)
val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
