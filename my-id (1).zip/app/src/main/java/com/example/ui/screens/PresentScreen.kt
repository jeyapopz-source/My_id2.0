package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.IdCardEntity
import com.example.ui.DisclosureAttribute
import com.example.ui.IdViewModel
import com.example.ui.components.BarcodeView
import com.example.ui.components.BrandHeader
import com.example.ui.components.QrCodeView
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandOrange
import kotlinx.coroutines.delay

@Composable
fun PresentScreen(
    viewModel: IdViewModel,
    modifier: Modifier = Modifier
) {
    val cards by viewModel.filteredCards.collectAsState()
    val preselectedCard by viewModel.selectedCardForPresent.collectAsState()
    val isMasked by viewModel.isMaskingEnabled.collectAsState()
    val isNfcTransmitting by viewModel.isNfcTransmitting.collectAsState()
    val nfcStatusMessage by viewModel.nfcStatusMessage.collectAsState()
    val disclosedAttributes by viewModel.disclosedAttributes.collectAsState()

    // Active card for presentation
    var activeCard by remember(cards, preselectedCard) {
        mutableStateOf(preselectedCard ?: cards.firstOrNull())
    }

    // Toggle between QR code and Barcode view
    var isBarcodeMode by remember { mutableStateOf(false) }

    // Dynamic rotating token counter (15 second security refresh cycle)
    var secondsRemaining by remember { mutableIntStateOf(15) }
    var nonceToken by remember { mutableStateOf("0A9F") }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            if (secondsRemaining > 1) {
                secondsRemaining -= 1
            } else {
                secondsRemaining = 15
                nonceToken = (1000..9999).random().toString(16).uppercase()
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 88.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Brand Header (without search)
        BrandHeader(
            isMasked = isMasked,
            onToggleMask = { viewModel.toggleMasking() },
            onLockVault = { viewModel.lockVault() },
            searchQuery = "",
            onSearchChange = {},
            showSearch = false
        )

        // Title Row
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = "Present Credential",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Dynamic zero-knowledge proof for terminal or scanner",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Card Selector Pills / Mini Cards
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(cards) { card ->
                val isSelected = activeCard?.id == card.id
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier
                        .clickable {
                            activeCard = card
                            viewModel.setCardForPresent(card)
                        }
                        .testTag("present_selector_${card.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = when (card.category) {
                                "Government" -> Icons.Default.Security
                                "Corporate" -> Icons.Default.Work
                                "Healthcare" -> Icons.Default.LocalHospital
                                else -> Icons.Default.CreditCard
                            },
                            contentDescription = null,
                            tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Column {
                            Text(
                                text = card.title,
                                fontSize = 12.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = card.category,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        activeCard?.let { card ->
            // Active Presentation Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Security Rotating Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(BrandGreen)
                            )
                            Text(
                                text = "CRYPTOGRAPHIC LIVE TOKEN",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrandGreen,
                                letterSpacing = 0.8.sp
                            )
                        }

                        // Countdown Pill
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = "Expires in ${secondsRemaining}s",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // QR / Barcode Display
                    val payloadWithNonce = "${card.qrPayload}&nonce=${nonceToken}&sec=${secondsRemaining}"

                    if (isBarcodeMode) {
                        BarcodeView(
                            payload = card.barcodePayload + nonceToken,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = card.barcodePayload,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    } else {
                        Box(
                            modifier = Modifier.size(210.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            QrCodeView(
                                payload = payloadWithNonce,
                                modifier = Modifier.fillMaxSize(),
                                backgroundColor = Color.White,
                                codeColor = Color(0xFF060D1E)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Mode switch toggle: QR vs Barcode
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (!isBarcodeMode) MaterialTheme.colorScheme.surface else Color.Transparent,
                            modifier = Modifier.clickable { isBarcodeMode = false }
                        ) {
                            Text(
                                text = "QR Matrix",
                                fontSize = 11.sp,
                                fontWeight = if (!isBarcodeMode) FontWeight.Bold else FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isBarcodeMode) MaterialTheme.colorScheme.surface else Color.Transparent,
                            modifier = Modifier.clickable { isBarcodeMode = true }
                        ) {
                            Text(
                                text = "Barcode",
                                fontSize = 11.sp,
                                fontWeight = if (isBarcodeMode) FontWeight.Bold else FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                    Spacer(modifier = Modifier.height(14.dp))

                    // Disclosed Attributes Summary
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text(
                            text = "DISCLOSED ATTRIBUTES",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (disclosedAttributes.contains(DisclosureAttribute.FULL_NAME)) {
                                AttributeChip("Full Legal Name")
                            }
                            if (disclosedAttributes.contains(DisclosureAttribute.AGE_OVER_21_ONLY)) {
                                AttributeChip("Age Over 21")
                            }
                            if (disclosedAttributes.contains(DisclosureAttribute.BIOMETRIC_PHOTO)) {
                                AttributeChip("Biometric Photo")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // NFC Tap to Transmit Action Area
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isNfcTransmitting) {
                        NfcPulsingAnimation()
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = nfcStatusMessage ?: "Transmitting via Secure Element...",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    } else {
                        Button(
                            onClick = { viewModel.triggerNfcTransmit(card) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("nfc_transmit_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(imageVector = Icons.Default.Nfc, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Hold Near Terminal (Simulate NFC)", fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Supports ISO 18013-5 & Apple/Google Wallet readers",
                            fontSize = 10.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AttributeChip(label: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
    ) {
        Text(
            text = label,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
private fun NfcPulsingAnimation() {
    val infiniteTransition = rememberInfiniteTransition(label = "nfc_pulse")
    val radiusRatio by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radius"
    )
    val alphaRatio by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "alpha"
    )

    Box(
        modifier = Modifier.size(90.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.width / 2f
            drawCircle(
                color = Color(0xFF00B0FF).copy(alpha = alphaRatio),
                radius = maxRadius * radiusRatio,
                center = center,
                style = Stroke(width = 3.dp.toPx())
            )
        }
        Icon(
            imageVector = Icons.Default.Nfc,
            contentDescription = null,
            tint = Color(0xFF0D47A1),
            modifier = Modifier.size(36.dp)
        )
    }
}
