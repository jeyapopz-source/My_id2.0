package com.example.ui

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.AuditLogEntity
import com.example.data.IdCardEntity
import com.example.data.IdRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class VerificationResult(
    val isValid: Boolean,
    val cardTitle: String,
    val holderName: String,
    val documentNumber: String,
    val issuer: String,
    val signatureAlgorithm: String,
    val isExpired: Boolean,
    val isRevoked: Boolean,
    val attributesVerified: List<String>,
    val timestamp: Long = System.currentTimeMillis()
)

enum class DisclosureAttribute {
    FULL_NAME,
    AGE_OVER_21_ONLY,
    EXACT_DOB,
    DOCUMENT_NUMBER,
    ADDRESS,
    BIOMETRIC_PHOTO,
    EMERGENCY_DATA
}

class IdViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: IdRepository

    init {
        val database = AppDatabase.getInstance(application)
        repository = IdRepository(database.idDao())
        viewModelScope.launch {
            repository.ensureInitialData()
        }
    }

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _isMaskingEnabled = MutableStateFlow(true)
    val isMaskingEnabled = _isMaskingEnabled.asStateFlow()

    private val _isVaultLocked = MutableStateFlow(false)
    val isVaultLocked = _isVaultLocked.asStateFlow()

    private val _selectedCardForDetail = MutableStateFlow<IdCardEntity?>(null)
    val selectedCardForDetail = _selectedCardForDetail.asStateFlow()

    private val _selectedCardForPresent = MutableStateFlow<IdCardEntity?>(null)
    val selectedCardForPresent = _selectedCardForPresent.asStateFlow()

    private val _isNfcTransmitting = MutableStateFlow(false)
    val isNfcTransmitting = _isNfcTransmitting.asStateFlow()

    private val _nfcStatusMessage = MutableStateFlow<String?>(null)
    val nfcStatusMessage = _nfcStatusMessage.asStateFlow()

    private val _verificationResult = MutableStateFlow<VerificationResult?>(null)
    val verificationResult = _verificationResult.asStateFlow()

    private val _disclosedAttributes = MutableStateFlow(
        setOf(
            DisclosureAttribute.FULL_NAME,
            DisclosureAttribute.AGE_OVER_21_ONLY,
            DisclosureAttribute.BIOMETRIC_PHOTO
        )
    )
    val disclosedAttributes = _disclosedAttributes.asStateFlow()

    val auditLogs: StateFlow<List<AuditLogEntity>> = repository.allAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredCards: StateFlow<List<IdCardEntity>> = combine(
        repository.allCards,
        _selectedCategory,
        _searchQuery
    ) { cards, category, query ->
        var list = cards
        if (category != "All") {
            list = list.filter { it.category.equals(category, ignoreCase = true) }
        }
        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                it.holderName.lowercase().contains(q) ||
                it.documentNumber.lowercase().contains(q) ||
                it.issuingAuthority.lowercase().contains(q)
            }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleMasking() {
        _isMaskingEnabled.value = !_isMaskingEnabled.value
    }

    fun lockVault() {
        _isVaultLocked.value = true
    }

    fun unlockVault(pin: String): Boolean {
        // Master PIN is 1234 or biometric simulated
        if (pin == "1234" || pin.isEmpty()) {
            _isVaultLocked.value = false
            return true
        }
        return false
    }

    fun showCardDetail(card: IdCardEntity?) {
        _selectedCardForDetail.value = card
    }

    fun setCardForPresent(card: IdCardEntity) {
        _selectedCardForPresent.value = card
    }

    fun togglePin(card: IdCardEntity) {
        viewModelScope.launch {
            repository.togglePin(card)
        }
    }

    fun deleteCard(card: IdCardEntity) {
        viewModelScope.launch {
            repository.deleteCard(card)
            if (_selectedCardForDetail.value?.id == card.id) {
                _selectedCardForDetail.value = null
            }
        }
    }

    fun addCard(card: IdCardEntity) {
        viewModelScope.launch {
            repository.insertCard(card)
        }
    }

    fun toggleDisclosure(attr: DisclosureAttribute) {
        val current = _disclosedAttributes.value.toMutableSet()
        if (current.contains(attr)) {
            current.remove(attr)
        } else {
            current.add(attr)
        }
        _disclosedAttributes.value = current
    }

    fun triggerNfcTransmit(card: IdCardEntity) {
        viewModelScope.launch {
            _isNfcTransmitting.value = true
            _nfcStatusMessage.value = "Holding near reader..."
            vibrateDevice(50)
            delay(1200)
            vibrateDevice(150)
            _nfcStatusMessage.value = "Identity Exchanged! Cryptographically Verified."
            // Add audit log
            repository.addAuditLog(
                AuditLogEntity(
                    cardTitle = card.title,
                    verifierName = "Contactless Security Gate",
                    timestamp = System.currentTimeMillis(),
                    attributesShared = getDisclosedSummary(card),
                    verificationMethod = "NFC_TAP",
                    status = "SUCCESS"
                )
            )
            delay(2000)
            _isNfcTransmitting.value = false
            _nfcStatusMessage.value = null
        }
    }

    fun simulateVerification(card: IdCardEntity, verifierLocation: String) {
        viewModelScope.launch {
            val result = VerificationResult(
                isValid = true,
                cardTitle = card.title,
                holderName = card.holderName,
                documentNumber = card.documentNumber,
                issuer = card.issuingAuthority,
                signatureAlgorithm = "ECDSA (secp256r1) with SHA-256 Digest",
                isExpired = false,
                isRevoked = false,
                attributesVerified = listOf(
                    "Identity Holder: ${card.holderName}",
                    "Issuer Trust: Authenticated (${card.issuingAuthority})",
                    "Document Status: VALID & ACTIVE",
                    "Security Level: ${card.securityLevel}",
                    "Replay Prevention Nonce: VALID"
                )
            )
            _verificationResult.value = result
            repository.addAuditLog(
                AuditLogEntity(
                    cardTitle = card.title,
                    verifierName = verifierLocation,
                    timestamp = System.currentTimeMillis(),
                    attributesShared = getDisclosedSummary(card),
                    verificationMethod = "QR_CODE",
                    status = "SUCCESS"
                )
            )
            vibrateDevice(100)
        }
    }

    fun clearVerificationResult() {
        _verificationResult.value = null
    }

    fun clearAuditLogs() {
        viewModelScope.launch {
            repository.clearAuditLogs()
        }
    }

    fun resetDemoData() {
        viewModelScope.launch {
            repository.resetDefaults()
        }
    }

    private fun getDisclosedSummary(card: IdCardEntity): String {
        val attrs = mutableListOf<String>()
        val current = _disclosedAttributes.value
        if (current.contains(DisclosureAttribute.FULL_NAME)) attrs.add("Legal Name")
        if (current.contains(DisclosureAttribute.AGE_OVER_21_ONLY)) attrs.add("Age > 21 Confirmation")
        if (current.contains(DisclosureAttribute.EXACT_DOB)) attrs.add("Birthdate (${card.dateOfBirth})")
        if (current.contains(DisclosureAttribute.DOCUMENT_NUMBER)) attrs.add("Doc #")
        if (current.contains(DisclosureAttribute.ADDRESS)) attrs.add("Address")
        if (current.contains(DisclosureAttribute.BIOMETRIC_PHOTO)) attrs.add("Verified Photo")
        if (attrs.isEmpty()) return "Basic Token Only"
        return attrs.joinToString(", ")
    }

    private fun vibrateDevice(durationMs: Long) {
        try {
            val context = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(durationMs)
                }
            }
        } catch (_: Exception) {
            // Ignore if vibration is unavailable
        }
    }
}
