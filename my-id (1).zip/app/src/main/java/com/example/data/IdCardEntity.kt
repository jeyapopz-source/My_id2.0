package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "id_cards")
data class IdCardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cardType: String, // NATIONAL_ID, DRIVERS_LICENSE, WORK_BADGE, PASSPORT, HEALTH_CARD, STUDENT_ID
    val title: String,
    val holderName: String,
    val documentNumber: String,
    val issuingAuthority: String,
    val issueDate: String,
    val expiryDate: String,
    val category: String, // Government, Corporate, Healthcare, Academic, Travel
    val status: String, // VERIFIED, ACTIVE, EXPIRING_SOON
    val securityLevel: String, // e.g. "Biometric Tier 3", "ISO 18013-5", "FIDO2 Level 4"
    val qrPayload: String,
    val barcodePayload: String,
    val themeGradient: String, // BLUE_VORTEX, ORANGE_AMBER, EMERALD_SHIELD, CARBON_BLACK, ROYAL_PURPLE
    val isPinned: Boolean = false,
    val dateOfBirth: String = "",
    val address: String = "",
    val departmentOrClass: String = "",
    val bloodType: String = "",
    val emergencyContact: String = "",
    val mrzCode: String = ""
)
