package com.example.data

import kotlinx.coroutines.flow.Flow

class IdRepository(private val idDao: IdDao) {
    val allCards: Flow<List<IdCardEntity>> = idDao.getAllCards()
    val allAuditLogs: Flow<List<AuditLogEntity>> = idDao.getAllAuditLogs()

    suspend fun getCardById(id: Long): IdCardEntity? = idDao.getCardById(id)

    suspend fun insertCard(card: IdCardEntity): Long = idDao.insertCard(card)

    suspend fun updateCard(card: IdCardEntity) = idDao.updateCard(card)

    suspend fun deleteCard(card: IdCardEntity) = idDao.deleteCard(card)

    suspend fun deleteCardById(id: Long) = idDao.deleteCardById(id)

    suspend fun togglePin(card: IdCardEntity) {
        idDao.updateCard(card.copy(isPinned = !card.isPinned))
    }

    suspend fun addAuditLog(log: AuditLogEntity) = idDao.insertAuditLog(log)

    suspend fun clearAuditLogs() = idDao.clearAuditLogs()

    suspend fun resetDefaults() {
        val defaultCards = SampleData.getDefaultCards()
        val defaultLogs = SampleData.getDefaultAuditLogs()
        idDao.insertCards(defaultCards)
        idDao.insertAuditLogs(defaultLogs)
    }

    suspend fun ensureInitialData() {
        if (idDao.getCardCount() == 0) {
            idDao.insertCards(SampleData.getDefaultCards())
            idDao.insertAuditLogs(SampleData.getDefaultAuditLogs())
        }
    }
}
