package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cardTitle: String,
    val verifierName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val attributesShared: String,
    val verificationMethod: String, // QR_CODE, NFC_TAP, BLE_PROXIMITY, MANUAL_AUDIT
    val status: String // SUCCESS, FAILED
)
