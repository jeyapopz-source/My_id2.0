package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface IdDao {
    @Query("SELECT * FROM id_cards ORDER BY isPinned DESC, id DESC")
    fun getAllCards(): Flow<List<IdCardEntity>>

    @Query("SELECT * FROM id_cards WHERE id = :id")
    suspend fun getCardById(id: Long): IdCardEntity?

    @Query("SELECT * FROM id_cards WHERE category = :category ORDER BY isPinned DESC, id DESC")
    fun getCardsByCategory(category: String): Flow<List<IdCardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCard(card: IdCardEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCards(cards: List<IdCardEntity>)

    @Update
    suspend fun updateCard(card: IdCardEntity)

    @Delete
    suspend fun deleteCard(card: IdCardEntity)

    @Query("DELETE FROM id_cards WHERE id = :id")
    suspend fun deleteCardById(id: Long)

    @Query("SELECT COUNT(*) FROM id_cards")
    suspend fun getCardCount(): Int

    // Audit logs
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
    fun getAllAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLogs(logs: List<AuditLogEntity>)

    @Query("DELETE FROM audit_logs")
    suspend fun clearAuditLogs()
}
