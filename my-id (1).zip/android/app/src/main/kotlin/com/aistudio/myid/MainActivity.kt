package com.aistudio.myid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
